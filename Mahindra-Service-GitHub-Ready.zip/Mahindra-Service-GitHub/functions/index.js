
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();
const ADMIN_PASSWORD = defineSecret("ADMIN_PASSWORD");

function requireUser(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Please log in first.");
  return request.auth.uid;
}
function verifyAdmin(password) {
  if (typeof password !== "string" || password.length < 1 || password !== ADMIN_PASSWORD.value()) {
    throw new HttpsError("permission-denied", "Admin password is incorrect.");
  }
}
function validText(v, max=120) { return typeof v === "string" && v.trim().length > 0 && v.length <= max; }


exports.ensureInitialStock = onCall(async (request) => {
  requireUser(request);
  const markerRef = db.collection("settings").doc("initialStockSeeded");
  const partRef = db.collection("parts").doc("air-filter");
  await db.runTransaction(async tx => {
    const marker = await tx.get(markerRef);
    if (marker.exists) return;
    const part = await tx.get(partRef);
    if (!part.exists) {
      tx.set(partRef, { name: "Air filter", qty: 2, price: 1000, createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp() });
    }
    tx.set(markerRef, { completedAt: FieldValue.serverTimestamp() });
  });
  return { ok: true };
});

exports.adminSetPart = onCall({ secrets: [ADMIN_PASSWORD], enforceAppCheck: false }, async (request) => {
  requireUser(request);
  const { password, name, qty, price } = request.data || {};
  verifyAdmin(password);
  if (!validText(name) || !Number.isInteger(qty) || qty < 0 || !Number.isFinite(price) || price < 0) {
    throw new HttpsError("invalid-argument", "Invalid part details.");
  }
  const cleanName = name.trim();
  const key = cleanName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || Buffer.from(cleanName).toString("hex").slice(0, 60);
  const ref = db.collection("parts").doc(key);
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    tx.set(ref, { name: cleanName, qty, price, updatedAt: FieldValue.serverTimestamp(), createdAt: snap.exists ? snap.data().createdAt : FieldValue.serverTimestamp() }, { merge: true });
  });
  return { ok: true };
});

exports.saveService = onCall(async (request) => {
  const uid = requireUser(request);
  const { type, data, parts } = request.data || {};
  if (!["free", "paid"].includes(type) || !data || typeof data !== "object" || !Array.isArray(parts) || parts.length < 1 || parts.length > 60) {
    throw new HttpsError("invalid-argument", "Invalid service record.");
  }
  if (type === "free" && !validText(data.driver)) throw new HttpsError("invalid-argument", "Driver name is required.");
  if (type === "paid" && !validText(data.name)) throw new HttpsError("invalid-argument", "Customer name is required.");
  const profileSnap = await db.collection("users").doc(uid).get();
  const profile = profileSnap.exists ? profileSnap.data() : {};
  const counts = new Map();
  for (const item of parts) {
    if (!validText(item.partId, 100) || !Number.isInteger(item.qty) || item.qty < 1) throw new HttpsError("invalid-argument", "Invalid part or quantity.");
    counts.set(item.partId, (counts.get(item.partId) || 0) + item.qty);
  }
  const recordRef = db.collection("serviceRecords").doc();
  await db.runTransaction(async tx => {
    const refs = [...counts.keys()].map(id => db.collection("parts").doc(id));
    const snaps = await Promise.all(refs.map(ref => tx.get(ref)));
    const used = [];
    let total = 0;
    snaps.forEach((snap, i) => {
      if (!snap.exists) throw new HttpsError("not-found", "A selected part no longer exists.");
      const part = snap.data(), qty = counts.get(refs[i].id);
      if (!Number.isInteger(part.qty) || part.qty < qty) throw new HttpsError("failed-precondition", `Not enough stock for ${part.name}.`);
      const lineTotal = Number(part.price) * qty;
      total += lineTotal;
      used.push({ partId: refs[i].id, name: part.name, qty, price: Number(part.price), lineTotal });
    });
    snaps.forEach((snap, i) => tx.update(refs[i], { qty: snap.data().qty - counts.get(refs[i].id), updatedAt: FieldValue.serverTimestamp() }));
    tx.set(recordRef, { type, data, parts: used, total, createdBy: uid, createdByName: profile.name || "", createdAt: FieldValue.serverTimestamp() });
  });
  return { ok: true, id: recordRef.id };
});

exports.adminDeleteHistory = onCall({ secrets: [ADMIN_PASSWORD] }, async (request) => {
  requireUser(request);
  const { password, ids } = request.data || {};
  verifyAdmin(password);
  if (!Array.isArray(ids) || ids.length < 1 || ids.length > 300 || ids.some(id => typeof id !== "string" || id.length > 150)) {
    throw new HttpsError("invalid-argument", "Select between 1 and 300 history records.");
  }
  const batch = db.batch();
  ids.forEach(id => batch.delete(db.collection("serviceRecords").doc(id)));
  await batch.commit();
  return { ok: true, deleted: ids.length };
});
