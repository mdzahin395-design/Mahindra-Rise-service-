MAHINDRA SERVICE — GITHUB + FIREBASE + ANDROID APK
==================================================

এই ZIP-এ আছে:
1) Firebase-ভিত্তিক online website/PWA — সব মোবাইলে একই Stock ও History
2) Name + mobile + password login; login persistence; Logout
3) Stock: Add/Edit part, quantity ও price (Admin password ছাড়া হবে না)
4) Free Service ও Paid Service; Used Parts; automatic total
5) Save Service করলে document/history তৈরি হয় এবং stock এক transaction-এ কমে
6) Android WebView wrapper project + GitHub Actions APK build workflow

গুরুত্বপূর্ণ: এই ZIP সরাসরি live নয়। নিজের Firebase project-এর config বসিয়ে একবার setup করতে হবে।

A. GitHub-এ ZIP আপলোড (মোবাইল থেকে)
1. ZIP extract করতে Android ফোনে Files app / ZArchiver ব্যবহার করুন।
2. github.com খুলে আপনার mahindra-service repository খুলুন (না থাকলে New repository তৈরি করুন)।
3. Add file > Upload files দিয়ে ZIP-এর ভেতরের সব ফাইল/ফোল্ডার upload করুন; ZIP ফাইলটি একা upload করবেন না।
4. Commit changes চাপুন।

B. Firebase project তৈরি
1. console.firebase.google.com খুলে Create project করুন।
2. Project settings > General > Your apps > Web app (</>) > Register app।
3. Firebase config কপি করে public/firebase-config.js খুলুন; PASTE_ দিয়ে শুরু হওয়া placeholder-গুলো আসল config দিয়ে বদলে Commit করুন।
4. Firebase Console > Authentication > Get started > Sign-in method > Email/Password Enable করুন।
5. Firestore Database > Create database > Production mode নির্বাচন করুন। Rules GitHub workflow deploy করবে।
6. Cloud Functions deploy-এর জন্য Firebase project-এ Blaze billing plan লাগতে পারে। Billing account যুক্ত করার আগে usage budget/alerts ঠিক করুন।

C. GitHub Actions-এর জন্য ৩টি Secret যোগ করুন
GitHub repository > Settings > Secrets and variables > Actions > New repository secret:
- FIREBASE_PROJECT_ID = Firebase project-এর Project ID
- ADMIN_PASSWORD = আপনার Admin password (আপনি যে password নির্ধারণ করেছেন)
- FIREBASE_SERVICE_ACCOUNT = Google Cloud service account key JSON-এর সম্পূর্ণ content

Service account key:
Google Cloud Console > IAM & Admin > Service Accounts-এ service account তৈরি করে Firebase deploy-এর প্রয়োজনীয় permission দিন (Firebase Admin / Cloud Functions Admin / Service Account User / Service Usage Admin / Secret Manager Admin এবং Hosting/Firestore deploy permission)। তারপর Keys > Add key > Create new key > JSON; JSON file খুলে সম্পূর্ণ content FIREBASE_SERVICE_ACCOUNT secret-এ paste করুন। Secret কাউকে দেবেন না।

D. Online app deploy
GitHub repository > Actions > Deploy Mahindra Service online > Run workflow। সফল হলে Firebase Hosting URL হবে:
https://YOUR_PROJECT_ID.web.app

E. Android APK বানানো
1. Firebase Hosting URL তৈরি হওয়ার পর GitHub Settings > Secrets and variables > Actions-এ APP_URL নামে আরেকটি secret যোগ করুন। Value দিন: https://YOUR_PROJECT_ID.web.app
2. Actions > Build Mahindra Service APK > Run workflow।
3. Workflow শেষ হলে run page-এর Artifacts থেকে Mahindra-Service-APK ZIP download করুন। ZIP extract করে app-debug.apk install করুন। Android-এ Install unknown apps অনুমতি চাইলে browser/files app-কে অনুমতি দিন।

F. App install না করেও
Chrome-এ Firebase Hosting URL খুলে ⋮ > Install app / Add to Home screen চাপলে app-এর মতো ব্যবহার করতে পারবেন।

প্রাথমিক Stock:
প্রথম account login হলে Air filter — 2 pcs — ৳1000 per piece স্বয়ংক্রিয়ভাবে একবার seed হবে।

নিরাপত্তা ও সীমাবদ্ধতা:
- Admin password source code-এ নেই; GitHub Secret থেকে Firebase Secret Manager-এ পাঠানো হয়।
- Phone number-এর SMS OTP verification নেই। Password authentication আছে, কিন্তু ফোন নম্বরের মালিকানা যাচাই হয় না।
- Firebase web config public client config; এটি secret নয়।
- Shared database-এ সব authenticated user stock/history দেখতে এবং service save করতে পারে; stock edit ও history delete-এর জন্য Admin password লাগে।
- Admin password কাউকে দেবেন না। GitHub repository public করলে config দেখা গেলেও password Secret হিসেবে সুরক্ষিত থাকবে; তবু private repository রাখাই ভালো।
- Mahindra logo app icon হিসেবে দেওয়া আছে। আপনার নির্দিষ্ট front-page Mahindra photo এই প্যাকেজে না থাকলে public/mahindra-front.jpg নামে photo upload করে জানাবেন; login page-এ সেটি বসিয়ে দেব।
